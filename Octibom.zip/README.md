# Octibom
 A python flask web application to support Amazon listing automation.
